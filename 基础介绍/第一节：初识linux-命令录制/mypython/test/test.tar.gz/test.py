print('hello mypython!')
